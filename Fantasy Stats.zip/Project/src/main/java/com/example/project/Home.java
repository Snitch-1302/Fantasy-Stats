package com.example.project;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Home {
    Stage stage = new Stage();

    public Home() {
        //Image
        Image img = new Image("E:\\College\\4th Semester\\Java Programming Lab\\ics\\home.jpg");
        BackgroundImage bgi = new BackgroundImage(img, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
            new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false));
        Background bg = new Background(bgi);

        stage.setTitle("Home Page ");

        //GridPane
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(20);
        grid.setVgap(20);
        grid.setPadding(new Insets(20, 20, 20, 20));
        //grid.setBackground(bg);

        //Buttons
        Button rules = new Button("Rules Page");
        rules.setFont(Font.font("Arial", FontWeight.NORMAL, 20));
        grid.add(rules, 0, 0);

        Button leader = new Button("LeaderBoards Page");
        rules.setFont(Font.font("Arial", FontWeight.NORMAL, 20));
        grid.add(leader, 1, 0);

        Button team = new Button("Team Creation Page");
        team.setFont(Font.font("Arial", FontWeight.NORMAL, 20));
        grid.add(team, 0, 1);

        Button about = new Button("About Us Page");
        about.setFont(Font.font("Arial", FontWeight.NORMAL, 20));
        grid.add(about, 1, 1);

        //add a welcome message
        Text welcome = new Text("Welcome to Home Page!");
        welcome.setFont(Font.font("Arial", FontWeight.BOLD, 30));
        grid.add(welcome, 0, 2, 2, 1);


        //setting actions
        rules.setOnAction(e -> {
            Rules rule = new Rules();
            rule.show();
        });

        leader.setOnAction(e -> {
            LeaderBoard leaders = new LeaderBoard();
            leaders.show();
        });

        team.setOnAction(e -> {
            Team teams = new Team();
            teams.show();
        });

        about.setOnAction(e -> {
            About abouts = new About();
            abouts.show();
        });

        //BorderPane
        BorderPane border = new BorderPane();
        border.setCenter(grid);

        Scene scene = new Scene(border, 500, 500);
        stage.setScene(scene);
    }

    public void show() {
        stage.show();
    }

}
