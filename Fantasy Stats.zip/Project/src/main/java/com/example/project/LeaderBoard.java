package com.example.project;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class LeaderBoard {
    private Stage stage;
    public LeaderBoard(){
        stage = new Stage();
        //Image
        Image lbp = new Image("E:\\College\\4th Semester\\Java Programming Lab\\ics\\img.jpeg");
        BackgroundImage bgi = new BackgroundImage(lbp, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false));
        Background bg = new Background(bgi);

        //GridPane
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setPadding(new Insets(10, 10, 10, 10));
        gridPane.setHgap(20);
        gridPane.setVgap(10);
        gridPane.setBackground(bg);

        //Labels
        Label rankLabel = new Label("Rank");
        Label nameLabel = new Label("Name");
        Label scoreLabel = new Label("Score");
        // Add the column name labels to the grid pane
        gridPane.add(rankLabel, 0, 0);
        gridPane.add(nameLabel, 1, 0);
        gridPane.add(scoreLabel, 2, 0);

        LeaderboardEntry[] entries = {
                new LeaderboardEntry("John ", 2000),
                new LeaderboardEntry("Jane", 1500),
                new LeaderboardEntry("Bob", 1000),
                new LeaderboardEntry("Alice", 500),
                new LeaderboardEntry("Tom", 250),
        };

        for (int i = 0; i < entries.length; i++) {
            LeaderboardEntry entry = entries[i];

            Label rankEntryLabel = new Label(Integer.toString(i + 1));
            Label nameEntryLabel = new Label(entry.getName());
            Label scoreEntryLabel = new Label(Integer.toString(entry.getScore()));

            gridPane.add(rankEntryLabel, 0, i + 1);
            gridPane.add(nameEntryLabel, 1, i + 1);
            gridPane.add(scoreEntryLabel, 2, i + 1);
        }

        VBox vbox = new VBox();
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(10, 10, 10, 10));
        vbox.setSpacing(10);

        Label titleLabel = new Label("Leaderboard");
        titleLabel.setStyle("-fx-font-size: 40px; -fx-font-weight:bold;");
        vbox.getChildren().add(titleLabel);
        vbox.getChildren().add(gridPane);

        //Button
        Button rtn = new Button("Return to HomePage");
        gridPane.add(rtn, 1,3);
        //action for button
        rtn.setOnAction(e -> {
            Home home = new Home();
            home.show();
        });

        BorderPane border = new BorderPane();
        border.setCenter(vbox);

        Scene scene = new Scene(border, 400, 400);
        stage.setTitle("Leaderboard");
        stage.setScene(scene);

    }
    public void show(){
        stage.show();
    }

    private static class LeaderboardEntry {
        private String name;
        private int score;

        public LeaderboardEntry(String name, int score) {
            this.name = name;
            this.score = score;
        }

        public String getName() {
            return name;
        }

        public int getScore() {
            return score;
        }
    }


}