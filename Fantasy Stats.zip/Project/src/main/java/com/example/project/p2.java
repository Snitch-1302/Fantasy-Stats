package com.example.project;
import javafx.geometry.Insets;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

public class p2 {
    private GridPane grid;

    public p2() {
        // Create the grid pane
        grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setVgap(10);
        grid.setHgap(10);

        // Add some text
        Text text = new Text("This is the second page.");
        grid.add(text, 0, 0);
    }

    public GridPane getGrid() {
        return grid;
    }
}

