package com.example.project;

import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class About {
    Stage stage = new Stage();
    public About(){
        GridPane grid = new GridPane();
        // Add your gridpane content here
        Label AboutUsLabel = new Label("About Fanatsy11\n\n"
                + " In the fantasy cricket game, you select a virtual team by picking players from the two teams who will play the live match and compete with other participants. \n"
                + "Indians rarely love anything as passionately as cricket and they ensure to learn even the smallest stats or detail about their favorite player.\n"
                + "Cricket is more of a religion than a sport for its millions of fans based in India. As a result, fantasy cricket has gained extreme popularity in the country within a short period of time.\n"
                + " With the same intention we have tried to create a replica of fantasy cricket and offer the thrills as it does.\n"
                + "This is created extensively with the help of Javafx \n"
                + "***Created by ***\n\n"
                + "***Nanda Pranesh.S - 21pc19***\n\n"
                + "***Renukashree . M      - 21pc23***\n\n");
        AboutUsLabel.setWrapText(true);

        // Create the image
        Image image = new Image("E:\\College\\4th Semester\\Java Programming Lab\\Fantasy_Stats\\src\\main\\resources\\com\\example\\fantasy_stats\\about.jpeg");
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(500);
        imageView.setFitHeight(400);

        //Image pos
        GridPane.setHalignment(imageView, HPos.RIGHT);
        GridPane.setValignment(imageView, VPos.BOTTOM);

        //Text Pos
        GridPane.setHalignment(AboutUsLabel, HPos.LEFT);
        GridPane.setValignment(AboutUsLabel, VPos.BOTTOM);

        //Button
        Button rtn = new Button("Return To HomePage");
        grid.add(rtn, 1,3);
        //action for button
        rtn.setOnAction(e -> {
            Home home = new Home();
            home.show();
        });

        grid.add(AboutUsLabel,5,0);
        grid.add(imageView,1,1);
        grid.setPrefSize(400,400);
        Scene scene = new Scene(grid, 400, 400);
        stage.setScene(scene);
        stage.setTitle("About Creators");

    }

    public void show(){
        stage.show();
    }
}
