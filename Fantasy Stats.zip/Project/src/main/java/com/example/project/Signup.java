package com.example.project;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Signup{
    private Stage stage;
    public Signup(){
        //Image
        Image signup = new Image("E:\\College\\4th Semester\\Java Programming Lab\\ics\\signup.jpg");
        //Creating background
        BackgroundImage bgi = new BackgroundImage(signup, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false));
        Background bg = new Background(bgi);

        stage = new Stage();
        stage.setTitle("SignUp");

        //GridPane
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20,20,20,20));
        grid.setBackground(bg);


        //Labels
        Label name = new Label("Name:  ");
        TextField text1 = new TextField();
        grid.add(name, 0,0);
        grid.add(text1, 1, 0);

        Label mail = new Label("Email  ");
        TextField text2 = new TextField();
        grid.add(mail, 0, 1);
        grid.add(text2, 1, 1);

        Label passwd = new Label("Password   ");
        PasswordField text3 = new PasswordField();
        grid.add(passwd, 0, 2);
        grid.add(text3, 1, 2);

        //Button
        Button register = new Button("Register");
        Button close = new Button("Close");

        grid.add(register,1,3);
        grid.add(close, 1, 5);

        register.setOnAction(event -> {
            String name1 = text1.getText();
            String mail1 = text2.getText();
            String pass1 = text3.getText();

            //Data insertion into users table to be done
            try{
                String url = "jdbc:mysql://localhost:3306/fantasy_stats";
                String user = "root";
                String pass = "Luna@1207#";

                Connection conn = DriverManager.getConnection(url, user, pass);
                String sql = "insert into users(name, mail, passwd) values (?,?,?)";
                PreparedStatement stmt = conn.prepareCall(sql);
                stmt.setString(1, name1);
                stmt.setString(2, mail1);
                stmt.setString(3,pass1);
                stmt.executeUpdate();

                stmt.close();
                conn.close();

            } catch (SQLException e) {
                e.printStackTrace();
            }


            System.out.println("User created !");
        });

        //BorderPane
        BorderPane border = new BorderPane();
        border.setCenter(grid);

        Scene scene = new Scene(border, 500, 500);
        stage.setScene(scene);

        close.setOnAction(event -> {
            Login login = new Login();
            login.show();
        });
    }

    public void show(){
        stage.show();
    }

}