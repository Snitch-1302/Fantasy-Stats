package com.example.project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.sql.*;

public class Team {
    private Stage stage;
    private ObservableList<String> teamNames = FXCollections.observableArrayList();
    private ObservableList<String> teamNamesSelected = FXCollections.observableArrayList();

    public Team(){
        stage = new Stage();

        //GridPane
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10, 10, 10, 10));
        gridPane.setVgap(10);
        gridPane.setHgap(10);

        // connect to the database and retrieve the team names
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/fantasy_stats", "root", "Luna@1207#");
            Statement stmt = conn.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT teamname FROM team");
            while (rs.next()) {
                teamNames.add(rs.getString(1));
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // create the first team dropdown
        ComboBox<String> firstTeamDropdown = new ComboBox<>(teamNames);
        gridPane.add(new Label("Select first team:"), 0, 0);
        gridPane.add(firstTeamDropdown, 1, 0);

        // create the second team dropdown
        ComboBox<String> secondTeamDropdown = new ComboBox<>(teamNames);
        gridPane.add(new Label("Select second team:"), 0, 1);
        gridPane.add(secondTeamDropdown, 1, 1);
        gridPane.setAlignment(Pos.CENTER);

        //Button add
        Button add = new Button("Add");
        add.setOnAction(event -> {
            String team1 = firstTeamDropdown.getValue();
            String team2 = secondTeamDropdown.getValue();
            if(team1 != null && !teamNamesSelected.contains(team1) && team2 != null && !teamNamesSelected.contains(team2)){
                teamNamesSelected.add(team1);
                teamNamesSelected.add(team2);
            }
        });

        //Button remove
        Button rmv = new Button("Remove");
        rmv.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String team1 = firstTeamDropdown.getValue();
                String team2 = secondTeamDropdown.getValue();
                if(team1 != null && !teamNamesSelected.contains(team1) && team2 != null && !teamNamesSelected.contains(team2)){
                    teamNamesSelected.remove(team1);
                    teamNamesSelected.remove(team2);
                }
            }
        });

        //create buttons hbox
        HBox buttonsHBox = new HBox(10);
        buttonsHBox.getChildren().addAll(add, rmv);
        gridPane.add(buttonsHBox, 1, 2);

        //select button to finish team selection
        Button select = new Button("Select");
        select.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // do something with the selected players
                System.out.println("Selected Teams: " + teamNamesSelected);
                stage.close();
                Home home = new Home();
                home.show();
            }
        });

        gridPane.add(select, 1, 3);
        gridPane.setAlignment(Pos.CENTER);

        //BorderPane
        BorderPane border = new BorderPane();
        border.setCenter(gridPane);

        Scene scene = new Scene(border, 500, 500);
        stage.setTitle("Team Selector");
        stage.setScene(scene);

    }

    public void show(){
        stage.show();
    }
}
