package com.example.project;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application{
    @Override
    public void start(Stage stage) throws Exception {
        Image main = new Image("E:\\College\\4th Semester\\Java Programming Lab\\ics\\main.jpeg");
        BackgroundImage bgi = new BackgroundImage(main, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false));
        Background bg = new Background(bgi);

        Button loginbt = new Button("login");
        Button signupbt = new Button("signup");

        Text sceneTitle = new Text("Welcome to Fantasy 11 !!");
        sceneTitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(25,25,25,25));
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(20);
        grid.setVgap(20);
        grid.setBackground(bg);
        grid.add(sceneTitle, 0,0,2,1);
        grid.add(loginbt, 1,3);
        grid.add(signupbt, 1, 5);

        Scene scene = new Scene(grid, 400, 300);
        stage.setScene(scene);
        stage.setTitle("Home");
        stage.show();

        loginbt.setOnAction(event -> {
            Login login = new Login();
            login.show();
        });

        signupbt.setOnAction(event -> {
            Signup signup = new Signup();
            signup.show();
        });


    }
}