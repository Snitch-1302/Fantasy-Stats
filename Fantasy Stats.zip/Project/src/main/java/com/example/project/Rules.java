package com.example.project;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class Rules {
    Stage stage = new Stage();

    public Rules(){
        //Image
        Image rls = new Image("E:\\College\\4th Semester\\Java Programming Lab\\ics\\rules.jpg");
        BackgroundImage bgi = new BackgroundImage(rls, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false));
        Background bg = new Background(bgi);

        //GridPane
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20,20,20,20));
        grid.setVgap(20);
        grid.setHgap(20);
        grid.setAlignment(Pos.CENTER);
        grid.setBackground(bg);

        //Labels
        Label rulesLabel = new Label("Here are the rules:\n\n"
                + "1. Rule number one.\n"
                + "*Your Composition must satisfy these constraints :\n"
                + "Min. 2 Batsmen + Min. WK + Min. 2Bowlers\n"
                + "2. Rule number two.\n"
                + "*The points will be awarded accordingly : \n"
                + "*For each 10 runs scored 2 points are awarded.\n"
                + "*For each wicket taken 2 points are awarded.\n"
                + "*For each catch taken 1 point is awarded.\n"
                + "*For each run-out caused 1 point is awarded.\n"
                + "3. Rule number three.\n"
                + "*A team can use Max of 650 points after the overall team composition\n"
                + "4. Rule number four.\n"
                + "*Any kind of external downloads will lead to permanent ban of user.");
        grid.add(rulesLabel,0,0);

        //Buttons
        Button rtrn = new Button("return to home page");
        grid.add(rtrn, 1,3);
        //action for button
        rtrn.setOnAction(e -> {
            Home home = new Home();
            home.show();
        });

        //BorderPane
        BorderPane border = new BorderPane();
        border.setCenter(grid);

        Scene scene = new Scene(border, 500, 500);

        stage.setTitle("Rules Page");
        stage.setScene(scene);
    }


    public void show(){
        stage.show();
    }
}
