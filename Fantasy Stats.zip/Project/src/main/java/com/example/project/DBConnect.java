package com.example.project;

import java.sql.*;
public class DBConnect {
    public static void main(String[] args) throws Exception{
        String url = "jdbc:mysql://localhost:3306/fantasy_stats";
        String name = "root";
        String pass = "Luna@1207#";

        String query = "select TeamName from team";

        String userData = "";

        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn = DriverManager.getConnection(url,name,pass);

        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(query);

        while(rs.next()){
            userData = rs.getString(1);
            //userData = rs.getInt(1) + " : " + rs.getString(2);
            System.out.println(userData);
        }

        st.close();
        conn.close();

    }
}
