package com.example.project;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class p1 extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Create the grid pane
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setVgap(10);
        grid.setHgap(10);

        // Add some text and a button
        Text text = new Text("This is the first page.");
        grid.add(text, 0, 0);

        Button button = new Button("Go to the second page");
        grid.add(button, 0, 1);

        // Set the action for the button to open the second page
        button.setOnAction(event -> {
            // Create an instance of the second class and set its scene
            p2 secondPage = new p2();
            Scene secondScene = new Scene(secondPage.getGrid(), 400, 300);

            // Set the scene and show the stage
            primaryStage.setScene(secondScene);
        });

        // Set the scene and show the stage
        Scene scene = new Scene(grid, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
