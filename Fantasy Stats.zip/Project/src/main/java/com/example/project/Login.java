package com.example.project;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Login{
    private static final Logger LOGGER = Logger.getLogger(Login.class.getName());
    private Stage stage;
    public Login(){
        //Image
        Image lbg = new Image("E:\\College\\4th Semester\\Java Programming Lab\\ics\\login.jpg");
        //Creating background
        BackgroundImage bgi = new BackgroundImage(lbg, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false));
        Background bg = new Background(bgi);

        stage = new Stage();
        stage.setTitle("Login");

        //Grid
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(20);
        grid.setVgap(20);
        grid.setPadding(new Insets(20,20,20,20));
        grid.setBackground(bg);

        //Adding Placeholders
        Text sceneTitle = new Text("Welcome! ");
        sceneTitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(sceneTitle, 0,0,2,1);

        Label user = new Label ("Username  ");
        grid.add(user, 0, 1);
        TextField text1 = new TextField();
        grid.add(text1, 1,1);

        Label pass =  new Label("Password ");
        grid.add(pass, 0, 2);
        PasswordField text2 = new PasswordField();
        grid.add(text2, 1,2);

        //Button
        Button login = new Button("Login");
        grid.add(login, 1, 3);

        //set action for login button
        login.setOnAction(event -> {
            String username = user.getText();
            String password = pass.getText();
            String url = "jdbc:mysql://localhost:3306/fantasy_stats";
            String usernamed = "root";
            String passwd = "Luna@1207#";

            try{
                FileHandler fileHandler = new FileHandler("login.log");
                SimpleFormatter formatter = new SimpleFormatter();
                fileHandler.setFormatter(formatter);
                LOGGER.addHandler(fileHandler);
                LOGGER.info("User " + "Renuka " + "logged in successfully!");
                LOGGER.info("User ab logged in successfully!");

                Connection conn = DriverManager.getConnection(url, usernamed, passwd);
                Statement stmt = conn.createStatement();
                String sql = "SELECT * FROM users WHERE username='" + username + "' AND passwd='" + password + "'";

                //PreparedStatement stmt = conn.prepareCall(sql);
                //stmt.setString(1, username);
                //stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery("SELECT * FROM users WHERE name='" + username + "' AND passwd='" + password + "'");
                if(rs.next()){
                    System.out.println("User Logged In");
                    if(validateUser(username, password)){
                        System.out.println("Login is successful!");
                        LOGGER.info("User " + username + "logged in successfully!");
                        Home home = new Home();
                        home.show();
                    }
                    else{
                        LOGGER.warning("Failed to login for user " + username);
                        System.out.println("Login is unsuccessful!");
                    }
                }

                stmt.close();
                conn.close();

                /*
                if(validateUser(username, password)){
                    System.out.println("Login is successful!");
                    LOGGER.info("User " + username + "logged in successfully!");
                }
                else{
                    LOGGER.warning("Failed to login for user " + username);
                    System.out.println("Login is unsuccessful!");
                }
            }
                 */
        }catch (Exception e){
                e.printStackTrace();
            }
        });

        //Button for going to homepage
        Button rtn = new Button("HomePage");
        grid.add(rtn, 1,7);
        //action for button
        rtn.setOnAction(e -> {
            Home home = new Home();
            home.show();
        });

        //BorderPane
        BorderPane border = new BorderPane();
        border.setCenter(grid);

        Scene scene = new Scene(border, 500,500);
        stage.setScene(scene);
    }
    public void show(){
        stage.show();
    }

    public static void setupLogger(){
        try{
            FileHandler handle = new FileHandler("login.log", true);
            handle.setFormatter(new SimpleFormatter());
            LOGGER.addHandler(handle);
        }
        catch(IOException e){
            LOGGER.warning("Failed to create log file: " + e.getMessage());
        }
    }

    private boolean validateUser(String username, String password){

        //Data checking to be done from user table of database
        String s = "";
        Pattern pattern = Pattern.compile("[A-Z][A-Z][A-Z][0-9][0-9][0-9]");
        Matcher matcher = pattern.matcher(username);
        boolean match = matcher.find();
        //return match;
        return true;
    }

}